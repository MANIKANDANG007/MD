from django.db import models
from django.contrib.auth.models import User
from PIL import Image
from django.db import models

# Extending User Model Using a One-To-One Link
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    avatar = models.ImageField(default='default.jpg', upload_to='profile_images')
    bio = models.TextField()
    

    def __str__(self):
        return self.user.username

    # resizing images
    def save(self, *args, **kwargs):
        super().save()

        img = Image.open(self.avatar.path)
        if img.height > 100 or img.width > 100:
            new_img = (100, 100)
            img.thumbnail(new_img)
            img.save(self.avatar.path)


class surveyform(models.Model):
    #SURVEYFORM
    question1= models.TextField(default='')
    question2= models.TextField(default='')
    question3= models.TextField(default='')
    question4= models.TextField(default='')
    question5= models.TextField(default='')
    question6= models.TextField(default='')
    question7= models.TextField(default='')
    question8= models.TextField(default='')
    question9= models.TextField(default='')
    question10= models.TextField(default='')

    def save(self, *args, **kwargs):
        super().save()


